# LUCREI - Sistema de Gestão Financeira SaaS

## Overview
LUCREI is a comprehensive SaaS financial management system designed for small and medium-sized businesses. It offers robust management of organizations, clients, invoices, financial transactions, categories, cost centers, documents, tags, OFX imports, exports, and detailed reports. The project aims to provide a modern, responsive, and fully functional platform that centralizes financial operations and enhances business efficiency with a standardized, intuitive user experience.

## User Preferences
- I prefer simple language and clear explanations.
- I want iterative development with frequent updates and feedback loops.
- Ask before making major changes to the core architecture or existing functionalities.
- Ensure all new features align with the established design system and visual patterns.
- Prioritize security and data integrity in all implementations.
- Do not make changes to the file `design_guidelines.md`.

## System Architecture
LUCREI is built with a client-server architecture using **React 18** (Vite) for the frontend and **Express.js** (Node.js 20) for the backend. **TypeScript** is used across the entire stack for type safety.

### UI/UX Decisions
The system follows a modern, standardized design with a focus on responsiveness and user-friendliness.
- **Consistent Design System:** All pages adhere to a modern visual standard using `shadcn/ui` components.
- **Theming:** Supports dark/light themes with `next-themes`.
- **Animations:** Smooth transitions and micro-interactions are implemented using `Framer Motion`.
- **Visuals:** Features gradients in titles (`bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent`), colored cards with shadows, gradient-backed Lucide React icons, and colored badges for status indicators.
- **Data Visualization:** Interactive charts and graphs are powered by `Recharts`.

### Technical Implementations
- **Backend:**
    - **Database:** PostgreSQL with `Drizzle ORM` for schema management and data access.
    - **API:** Full RESTful API supporting CRUD operations for all entities (Organizations, Users, Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Subscriptions). Includes dedicated endpoints for metrics, activity logs, OFX reconciliations, and financial reports.
    - **Authentication:** Session-based authentication using `Passport.js` and `express-session`, with password hashing via `bcryptjs` (10 rounds).
    - **Authorization:** Role-based access control (OWNER, ADMIN, CUSTOMER) and organization-level data isolation.
    - **Validation:** Server-side data validation using `Zod`.
    - **Security:** `Helmet` for HTTP headers, CORS configured, `express-rate-limit` for rate limiting.
- **Frontend:**
    - **State Management & Data Fetching:** `TanStack Query (React Query)` handles data fetching, caching, and synchronization.
    - **Routing:** Light-weight client-side routing with `Wouter`.
    - **Form Management:** `React Hook Form` integrated with `Zod` for client-side validation.

### Feature Specifications
- **Core Modules:** Management for Customers, Invoices, Transactions, Categories, Cost Centers, Tags, Documents, Bank Accounts, and Subscriptions.
- **Dashboard:** Centralized view with key metrics, interactive charts, recent activities, and invoice statistics.
- **Reporting:** Comprehensive financial reports including DRE (Income Statement), Cash Flow, and Transaction Statements with export capabilities.
- **Data Operations:** OFX import and reconciliation, generalized data import (standard, Zero Paper, contacts), and export functionalities (Excel, CSV, PDF, JSON).
- **Settings:** Configurable settings for organization, user account, and preferences including security, notifications, appearance, and regionalization.

### System Design Choices
- **Modularity:** Project structure separates client, server, and shared code (`lucrei/client`, `lucrei/server`, `lucrei/shared`).
- **Scalability:** Designed with considerations for future scalability, including potential for queue systems, distributed caching, and CDN integration.
- **Observability:** Focus on logging and monitoring in production environments.
- **Deployment:** Configured for automated deployment on Replit and compatible with manual production deployments.

## External Dependencies
- **Stripe:** For payment processing and subscription management.
- **PostgreSQL:** Primary database, utilized with `@neondatabase/serverless` for serverless environments.
- **Passport.js:** Authentication middleware.
- **bcryptjs:** Password hashing library.
- **Zod:** Schema declaration and validation library (used both frontend and backend).
- **Recharts:** Charting library for data visualization.
- **Lucide React:** Icon library.
- **Framer Motion:** Animation library.
- **TanStack Query (React Query):** Data fetching and caching library.
- **shadcn/ui:** UI component library.
- **Tailwind CSS:** Utility-first CSS framework.
- **Vite:** Frontend build tool.
- **Node.js 20:** JavaScript runtime environment.