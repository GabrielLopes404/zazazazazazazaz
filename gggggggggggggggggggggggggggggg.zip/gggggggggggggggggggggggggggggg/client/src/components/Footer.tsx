import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Linkedin, Twitter, Instagram } from "lucide-react";
import { motion } from "framer-motion";

export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-muted/30 to-muted/50 border-t">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-12">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-2"
          >
            <div className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent mb-4">
              LUCREI
            </div>
            <p className="text-muted-foreground mb-6 max-w-sm leading-relaxed">
              Controle financeiro simples para quem quer crescer. Gestão completa para sua empresa.
            </p>
            <div className="flex gap-3">
              {[
                { Icon: Linkedin, name: 'linkedin' },
                { Icon: Twitter, name: 'twitter' },
                { Icon: Instagram, name: 'instagram' }
              ].map(({ Icon, name }, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.1 * i, duration: 0.3 }}
                  whileHover={{ scale: 1.1, y: -2 }}
                >
                  <Button 
                    size="icon" 
                    variant="outline"
                    className="hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300"
                    data-testid={`button-social-${name}`}
                  >
                    <Icon className="h-4 w-4" />
                  </Button>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {[
            { title: 'Produto', links: [
              { name: 'Funcionalidades', href: '#', testid: 'link-features' },
              { name: 'Preços', href: '#', testid: 'link-pricing' },
              { name: 'Integrações', href: '#', testid: 'link-integrations' },
              { name: 'API', href: '#', testid: 'link-api' }
            ]},
            { title: 'Empresa', links: [
              { name: 'Sobre nós', href: '#', testid: 'link-about' },
              { name: 'Blog', href: '#', testid: 'link-blog' },
              { name: 'Carreiras', href: '#', testid: 'link-careers' },
              { name: 'Contato', href: '#', testid: 'link-contact' }
            ]},
            { title: 'Recursos', links: [
              { name: 'Central de Ajuda', href: '#', testid: 'link-help' },
              { name: 'Documentação', href: '#', testid: 'link-docs' },
              { name: 'Status', href: '#', testid: 'link-status' },
              { name: 'Segurança', href: '#', testid: 'link-security' }
            ]}
          ].map((section, sectionIndex) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 * sectionIndex, duration: 0.5 }}
            >
              <h3 className="font-semibold mb-4">{section.title}</h3>
              <div className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <motion.div
                    key={link.name}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 * sectionIndex + 0.05 * linkIndex }}
                  >
                    <Link 
                      href={link.href}
                      className="block text-sm text-muted-foreground hover:text-primary transition-colors group"
                      data-testid={link.testid}
                    >
                      <span className="relative">
                        {link.name}
                        <span className="absolute -bottom-0.5 left-0 w-0 h-px bg-primary transition-all duration-300 group-hover:w-full" />
                      </span>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="border-t pt-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-muted-foreground">
              © 2025 LUCREI. Todos os direitos reservados.
            </div>
            <div className="flex gap-6 text-sm">
              {[
                { name: 'Privacidade', testid: 'link-privacy' },
                { name: 'Termos de Uso', testid: 'link-terms' },
                { name: 'Cookies', testid: 'link-cookies' }
              ].map((link, i) => (
                <motion.div
                  key={link.name}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4 + i * 0.1 }}
                >
                  <Link 
                    href="#"
                    className="text-muted-foreground hover:text-primary transition-colors"
                    data-testid={link.testid}
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
