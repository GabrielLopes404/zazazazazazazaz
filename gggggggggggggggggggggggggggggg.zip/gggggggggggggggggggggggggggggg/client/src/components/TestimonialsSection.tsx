import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star, Quote, Sparkles } from "lucide-react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";

const testimonials = [
  {
    name: "Maria Silva",
    role: "CEO",
    company: "TechStart Solutions",
    content: "O LUCREI transformou completamente nossa gestão financeira. Conseguimos reduzir em 70% o tempo gasto com administração e temos visibilidade total do nosso fluxo de caixa.",
    rating: 5,
    gradient: "from-violet-500 via-purple-500 to-fuchsia-500",
    glowColor: "rgba(139, 92, 246, 0.4)"
  },
  {
    name: "Roberto Santos",
    role: "Diretor Financeiro",
    company: "Construtora Moderna",
    content: "Finalmente encontramos um sistema que é ao mesmo tempo poderoso e fácil de usar. A automação de cobranças nos economizou incontáveis horas todo mês.",
    rating: 5,
    gradient: "from-cyan-500 via-blue-500 to-indigo-500",
    glowColor: "rgba(6, 182, 212, 0.4)"
  },
  {
    name: "Ana Costa",
    role: "Fundadora",
    company: "Studio Criativo",
    content: "Como freelancer, sempre tive dificuldade com organização financeira. O LUCREI me deu controle total e profissionalismo nas minhas cobranças. Recomendo de olhos fechados!",
    rating: 5,
    gradient: "from-pink-500 via-rose-500 to-red-500",
    glowColor: "rgba(236, 72, 153, 0.4)"
  }
];

export default function TestimonialsSection() {
  const ref = useRef(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["80px", "-80px"]);

  return (
    <section ref={containerRef} id="depoimentos" className="relative py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Enhanced gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-cyan-500/5 via-violet-500/5 to-background" />
      
      {/* Animated gradient orbs */}
      <motion.div
        style={{ y }}
        className="absolute top-10 left-20 w-[400px] h-[400px] bg-gradient-to-r from-violet-500/20 to-purple-500/20 rounded-full blur-3xl"
      />
      <motion.div
        style={{ y: useTransform(scrollYProgress, [0, 1], ["-40px", "120px"]) }}
        className="absolute bottom-10 right-20 w-[400px] h-[400px] bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-full blur-3xl"
      />

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.02)_1px,transparent_1px)] bg-[size:64px_64px]" />
      
      <div ref={ref} className="max-w-[1440px] mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6, type: "spring" }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-violet-500/10 via-purple-500/10 to-cyan-500/10 border border-violet-500/20 backdrop-blur-xl shadow-lg mb-8 relative overflow-hidden"
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
              animate={{ x: ['-200%', '200%'] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
            />
            <Quote className="h-5 w-5 text-violet-500" />
            <span className="text-sm font-bold bg-gradient-to-r from-violet-600 via-purple-600 to-cyan-600 bg-clip-text text-transparent">
              ⭐ Histórias de Sucesso
            </span>
          </motion.div>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight" data-testid="text-testimonials-title">
            <span className="bg-gradient-to-r from-foreground to-foreground/90 bg-clip-text text-transparent">
              Quem usa,
            </span>
            <br />
            <span className="relative inline-block">
              <motion.span
                className="absolute -inset-2 bg-gradient-to-r from-violet-500 via-purple-500 to-cyan-500 blur-2xl opacity-30"
                animate={{ opacity: [0.3, 0.5, 0.3] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              <span className="relative bg-gradient-to-r from-violet-600 via-purple-600 to-cyan-600 bg-clip-text text-transparent">
                aprova e cresce
              </span>
            </span>
          </h2>
          <p className="text-xl sm:text-2xl text-muted-foreground max-w-3xl mx-auto font-light" data-testid="text-testimonials-subtitle">
            Veja o que nossos clientes têm a dizer sobre sua{" "}
            <span className="font-semibold text-foreground">jornada de transformação</span>
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 60, rotateX: -10 }}
              animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
              transition={{ 
                delay: 0.2 + index * 0.15, 
                duration: 0.8,
                type: "spring",
                stiffness: 100
              }}
              whileHover={{ y: -12, scale: 1.02 }}
              style={{ transformStyle: 'preserve-3d', perspective: '1000px' }}
            >
              <Card 
                className="p-8 h-full transition-all duration-500 border border-violet-500/10 backdrop-blur-xl bg-gradient-to-br from-background/80 via-background/50 to-background/80 hover:border-violet-500/30 relative overflow-hidden group shadow-xl hover:shadow-2xl"
                data-testid={`card-testimonial-${index}`}
              >
                {/* Animated gradient background on hover */}
                <motion.div
                  className={`absolute -inset-px bg-gradient-to-br ${testimonial.gradient} rounded-lg opacity-0 group-hover:opacity-20 blur-xl transition-all duration-700`}
                  style={{ filter: 'blur(20px)' }}
                />

                {/* Shimmer effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100"
                  animate={{
                    x: ['-200%', '200%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatDelay: 3,
                    ease: "linear"
                  }}
                />
                
                {/* Gradient border on hover */}
                <div className={`absolute -inset-0.5 bg-gradient-to-br ${testimonial.gradient} rounded-lg opacity-0 group-hover:opacity-100 blur transition-opacity duration-500 -z-10`} />

                <div className="relative z-10 space-y-6">
                  {/* Enhanced stars with animation */}
                  <motion.div 
                    className="flex gap-1.5"
                    initial={{ opacity: 0 }}
                    animate={isInView ? { opacity: 1 } : {}}
                    transition={{ delay: 0.4 + index * 0.15 }}
                  >
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0, rotate: -180 }}
                        animate={isInView ? { opacity: 1, scale: 1, rotate: 0 } : {}}
                        transition={{ 
                          delay: 0.5 + index * 0.15 + i * 0.05,
                          type: "spring",
                          stiffness: 300,
                          damping: 15
                        }}
                        whileHover={{ scale: 1.3, rotate: 180 }}
                      >
                        <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 drop-shadow-lg" />
                      </motion.div>
                    ))}
                  </motion.div>
                  
                  {/* Quote with enhanced styling */}
                  <div className="relative">
                    <motion.div
                      animate={{ 
                        scale: [1, 1.1, 1],
                        opacity: [0.2, 0.3, 0.2]
                      }}
                      transition={{ duration: 4, repeat: Infinity }}
                      className="absolute -top-4 -left-4 w-16 h-16 rounded-full bg-gradient-to-br from-violet-500/10 to-purple-500/10 blur-xl"
                    />
                    <Quote className="absolute -top-2 -left-2 h-10 w-10 text-violet-500/30 group-hover:text-violet-500/50 transition-colors duration-500" />
                    <p className="text-base text-muted-foreground leading-relaxed relative z-10 pl-8 group-hover:text-foreground/90 transition-colors duration-300 font-medium" data-testid={`text-testimonial-content-${index}`}>
                      {testimonial.content}
                    </p>
                  </div>

                  {/* Enhanced author section */}
                  <div className="flex items-center gap-4 pt-4 border-t border-border/50 group-hover:border-violet-500/20 transition-colors duration-500">
                    <motion.div
                      whileHover={{ scale: 1.15, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 300, damping: 10 }}
                      className="relative"
                    >
                      <motion.div
                        className={`absolute -inset-2 bg-gradient-to-br ${testimonial.gradient} rounded-full blur-lg opacity-0 group-hover:opacity-50 transition-opacity duration-500`}
                      />
                      <Avatar className={`h-14 w-14 border-2 border-transparent bg-gradient-to-br ${testimonial.gradient} p-0.5 shadow-lg`}
                        style={{ boxShadow: `0 8px 32px ${testimonial.glowColor}` }}
                      >
                        <AvatarFallback className="bg-background/90 text-foreground font-bold text-lg backdrop-blur-sm">
                          {testimonial.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                    </motion.div>
                    <div className="flex-1">
                      <div className={`font-bold text-base group-hover:bg-gradient-to-r ${testimonial.gradient} group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300`} data-testid={`text-testimonial-name-${index}`}>
                        {testimonial.name}
                      </div>
                      <div className="text-sm text-muted-foreground font-medium" data-testid={`text-testimonial-role-${index}`}>
                        {testimonial.role} · {testimonial.company}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom gradient line */}
                <motion.div
                  className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${testimonial.gradient}`}
                  initial={{ scaleX: 0 }}
                  whileHover={{ scaleX: 1 }}
                  transition={{ duration: 0.4 }}
                />
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Enhanced stats section */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
          className="text-center mt-20 space-y-8"
        >
          <div className="flex flex-wrap justify-center gap-6">
            {[
              { value: '4.95/5', label: 'Avaliação média', icon: '⭐' },
              { value: '98%', label: 'Taxa de satisfação', icon: '💯' },
              { value: '12.5K+', label: 'Clientes felizes', icon: '🎉' }
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 1 + i * 0.1, type: "spring" }}
                whileHover={{ scale: 1.1, y: -5 }}
                className="relative group cursor-pointer"
              >
                <motion.div
                  className="absolute -inset-3 bg-gradient-to-r from-violet-500/30 via-purple-500/30 to-cyan-500/30 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                />
                <div className="relative px-8 py-5 rounded-2xl bg-gradient-to-r from-violet-500/10 to-cyan-500/10 border border-violet-500/20 backdrop-blur-sm">
                  <div className="text-3xl mb-2">{stat.icon}</div>
                  <div className="text-2xl font-bold bg-gradient-to-r from-violet-600 via-purple-600 to-cyan-600 bg-clip-text text-transparent font-mono tabular-nums">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground font-medium mt-1">{stat.label}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
